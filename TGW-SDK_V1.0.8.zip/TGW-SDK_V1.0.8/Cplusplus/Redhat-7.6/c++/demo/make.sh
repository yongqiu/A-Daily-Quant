mkdir bin
make
make install
make clean
LD_LIBRARY_PATH=./lib ./bin/tgw_demo