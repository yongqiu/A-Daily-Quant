#!/bin/bash
LD_LIBRARY_PATH=../lib ./bin/tgw_test --cfg-name ./etc/tgw.json