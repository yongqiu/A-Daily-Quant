使用说明：
1、如果windows环境中安装了Visual Studio 2015以上版本，则无需安装此VC_redist运行库；
2、由于API使用的是基于C++ 11开发，并且基于MSVC140编译，因此使用的Visual Studio版本需为2015及其以上版本；

MicroSoft Visual C++ Redistributable: 
是一个运行库，基于VC开发的程序在windwos 环境运行时，环境必须安装对应的运行库才可以正常运行，
一般来说我们安装对应VS软件时会安装对应的VC_dist, 我们也可以在官网下载对应的VC_redist版本

安装过程如下：
1、双击.exe文件
2、单击我同意许可条款和条件旁边的框
3、单击安装
4、安装后，单击重新启动以重启计算机
